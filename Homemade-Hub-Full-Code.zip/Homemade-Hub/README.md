# Homemade Hub — Homemade Food Marketplace

A beginner-friendly Spring Boot web application that lets home cooks list homemade food and customers place orders.

## Features

- View the homemade food menu
- Add, edit, and delete food listings
- Place orders with customer and delivery details
- Calculate the order total from the current food price and quantity
- View orders
- Responsive page styling

## Technologies

- Java 17
- Spring Boot 3.5.14
- Spring MVC and Thymeleaf
- Spring Data JPA / Hibernate
- MySQL
- HTML and CSS
- Maven

## Requirements

- JDK 17 or later
- Maven (or use Maven support in Eclipse/STS)
- MySQL Server

## Configure MySQL

The default configuration in `src/main/resources/application.properties` is:

- Database: `homemade_hub`
- Username: `root`
- Password: `root`

Change the username/password to match your local MySQL installation. You can also set environment variables:

- `DB_URL`
- `DB_USERNAME`
- `DB_PASSWORD`

The JDBC URL creates the database if it does not exist. The MySQL account must have permission to create it. Alternatively, run `database/schema.sql` first.

## Run in Eclipse

1. Extract the ZIP file.
2. Open Eclipse and choose **File → Import → Maven → Existing Maven Projects**.
3. Select the extracted `Homemade-Hub` folder and finish importing.
4. Edit `application.properties` if your MySQL password differs.
5. Start MySQL.
6. Right-click `FirstAppApplication.java` and choose **Run As → Java Application** or **Spring Boot App**.
7. Open `http://localhost:8080` in a browser.

## Run from a terminal

From the project folder:

```bash
mvn spring-boot:run
```

Then visit `http://localhost:8080`.

## Main routes

- `/` — home page and food menu
- `/foods/new` — add a food listing
- `/foods/{id}/edit` — edit a listing
- `/orders/new/{foodId}` — order a food item
- `/orders` — view orders

## Notes

This is a learning/demo project, not a production-ready marketplace. It does not yet include user authentication, online payments, inventory management, seller permissions, email notifications, or delivery tracking. Protect administrative actions and add authentication/authorization before public deployment. Do not use real customer information in a public demo.
