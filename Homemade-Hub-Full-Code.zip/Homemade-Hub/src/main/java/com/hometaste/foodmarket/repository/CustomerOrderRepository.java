package com.hometaste.foodmarket.repository;

import com.hometaste.foodmarket.model.CustomerOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long> {
    List<CustomerOrder> findAllByOrderByOrderDateDesc();
}
