package com.hometaste.foodmarket.controller;

import com.hometaste.foodmarket.service.FoodItemService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    private final FoodItemService foodItemService;

    public HomeController(FoodItemService foodItemService) {
        this.foodItemService = foodItemService;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("foods", foodItemService.findAll());
        return "index";
    }
}
