package com.hometaste.foodmarket.service;

import com.hometaste.foodmarket.model.CustomerOrder;
import com.hometaste.foodmarket.model.FoodItem;
import com.hometaste.foodmarket.repository.CustomerOrderRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.List;

@Service
public class CustomerOrderService {
    private final CustomerOrderRepository orderRepository;
    private final FoodItemService foodItemService;

    public CustomerOrderService(CustomerOrderRepository orderRepository, FoodItemService foodItemService) {
        this.orderRepository = orderRepository;
        this.foodItemService = foodItemService;
    }

    public List<CustomerOrder> findAll() {
        return orderRepository.findAllByOrderByOrderDateDesc();
    }

    public CustomerOrder placeOrder(CustomerOrder order) {
        FoodItem food = foodItemService.findById(order.getFoodItemId())
                .orElseThrow(() -> new IllegalArgumentException("Food item not found"));
        order.setFoodName(food.getName());
        order.setTotalPrice(food.getPrice().multiply(BigDecimal.valueOf(order.getQuantity())));
        order.setStatus("PLACED");
        return orderRepository.save(order);
    }
}
