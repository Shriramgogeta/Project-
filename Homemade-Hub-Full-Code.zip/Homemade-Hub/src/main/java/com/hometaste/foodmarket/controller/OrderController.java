package com.hometaste.foodmarket.controller;

import com.hometaste.foodmarket.model.CustomerOrder;
import com.hometaste.foodmarket.service.CustomerOrderService;
import com.hometaste.foodmarket.service.FoodItemService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/orders")
public class OrderController {
    private final CustomerOrderService orderService;
    private final FoodItemService foodItemService;

    public OrderController(CustomerOrderService orderService, FoodItemService foodItemService) {
        this.orderService = orderService;
        this.foodItemService = foodItemService;
    }

    @GetMapping("/new/{foodId}")
    public String newOrder(@PathVariable Long foodId, Model model) {
        var food = foodItemService.findById(foodId).orElseThrow();
        CustomerOrder order = new CustomerOrder();
        order.setFoodItemId(food.getId());
        order.setQuantity(1);
        model.addAttribute("order", order);
        model.addAttribute("food", food);
        return "order-form";
    }

    @PostMapping
    public String placeOrder(@Valid @ModelAttribute("order") CustomerOrder order,
                             BindingResult result, Model model, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            var food = foodItemService.findById(order.getFoodItemId()).orElseThrow();
            model.addAttribute("food", food);
            return "order-form";
        }
        try {
            CustomerOrder saved = orderService.placeOrder(order);
            redirectAttributes.addFlashAttribute("message", "Order #" + saved.getId() + " placed successfully!");
            return "redirect:/";
        } catch (IllegalArgumentException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("foods", foodItemService.findAll());
            return "index";
        }
    }

    @GetMapping
    public String allOrders(Model model) {
        model.addAttribute("orders", orderService.findAll());
        return "orders";
    }
}
