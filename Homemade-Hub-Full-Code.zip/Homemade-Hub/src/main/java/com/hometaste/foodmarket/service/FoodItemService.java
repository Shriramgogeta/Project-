package com.hometaste.foodmarket.service;

import com.hometaste.foodmarket.model.FoodItem;
import com.hometaste.foodmarket.repository.FoodItemRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class FoodItemService {
    private final FoodItemRepository repository;

    public FoodItemService(FoodItemRepository repository) {
        this.repository = repository;
    }

    public List<FoodItem> findAll() {
        return repository.findAll();
    }

    public Optional<FoodItem> findById(Long id) {
        return repository.findById(id);
    }

    public FoodItem save(FoodItem item) {
        return repository.save(item);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    public boolean existsById(Long id) {
        return repository.existsById(id);
    }
}
