package com.hometaste.foodmarket.controller;

import com.hometaste.foodmarket.model.FoodItem;
import com.hometaste.foodmarket.service.FoodItemService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/foods")
public class FoodItemController {
    private final FoodItemService foodItemService;

    public FoodItemController(FoodItemService foodItemService) {
        this.foodItemService = foodItemService;
    }

    @GetMapping("/new")
    public String newFood(Model model) {
        model.addAttribute("food", new FoodItem());
        return "food-form";
    }

    @PostMapping
    public String createFood(@Valid @ModelAttribute("food") FoodItem food,
                             BindingResult result, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) return "food-form";
        foodItemService.save(food);
        redirectAttributes.addFlashAttribute("message", "Food item added successfully.");
        return "redirect:/";
    }

    @GetMapping("/{id}/edit")
    public String editFood(@PathVariable Long id, Model model) {
        FoodItem food = foodItemService.findById(id).orElseThrow();
        model.addAttribute("food", food);
        return "food-form";
    }

    @PostMapping("/{id}/update")
    public String updateFood(@PathVariable Long id, @Valid @ModelAttribute("food") FoodItem food,
                             BindingResult result, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) return "food-form";
        food.setId(id);
        foodItemService.save(food);
        redirectAttributes.addFlashAttribute("message", "Food item updated successfully.");
        return "redirect:/";
    }

    @PostMapping("/{id}/delete")
    public String deleteFood(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        if (foodItemService.existsById(id)) foodItemService.deleteById(id);
        redirectAttributes.addFlashAttribute("message", "Food item deleted.");
        return "redirect:/";
    }
}
