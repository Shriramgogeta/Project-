CREATE DATABASE IF NOT EXISTS homemade_hub;
USE homemade_hub;

-- Spring Boot creates and updates the food_item and customer_orders tables
-- automatically through spring.jpa.hibernate.ddl-auto=update.
-- Optional sample records can be added through the website's Sell Food form.
